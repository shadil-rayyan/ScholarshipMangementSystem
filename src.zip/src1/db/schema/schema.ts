// src\db\schema\index.ts

export * from './scholarship/scholarshipData';

export * from './scholarship/VerificationLogs';

export * from './scholarship/savedata';

export * from './admin/categories';

export * from './admin/occupation';

export * from './admin/applyButton';
