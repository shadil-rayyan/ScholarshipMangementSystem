// constants.ts

export const ROOT_ROUTE = '/';
export const HOME_ROUTE = '';
export const ADMIN_ROUTE = '/Scholarships';
export const SESSION_COOKIE_NAME = 'user_session';