'use client'
import Navbar from "@/components/navbar";
import DarsanaScholarshipPage from '@/app/(client)/Scholarship/page'
const page = () => {
  return(
    <>
    <Navbar />
    <DarsanaScholarshipPage />

    
    </>



  ) 
};

export default page;



