import ApplyForm from '@/components/scholarship/client/applyComponent';
import React from 'react';

const page = () => {
    return (
        <div>
            <ApplyForm />
        </div>
    );
}

export default page;
