import { NextRequest, NextResponse } from 'next/server';
import { ScholarshipDb, Scholarship_Table, InsertScholarship } from '@/db/schema/scholarship/scholarshipData'; // Adjust the path to your Drizzle schema file

// Define the POST method handler
export async function POST(req: NextRequest) {
    try {
        // Parse the request body
        const body = await req.json();
        
        // Extract the necessary fields from the request body
        const scholarshipData: InsertScholarship = {
            // Personal Details
            name: body.personalDetails.name,
            dateOfBirth: new Date(body.personalDetails.dob),
            gender: body.personalDetails.gender,
            nationality: body.personalDetails.nationality,
            category: body.personalDetails.category,
            adharNumber: body.personalDetails.aadhar,
            fatherName: body.personalDetails.fatherName,
            fatherNumber: body.personalDetails.fatherPhone,
            motherName: body.personalDetails.motherName,
            motherNumber: body.personalDetails.motherPhone,
            income: body.personalDetails.income,
            fatherOccupation: body.personalDetails.fatherOccupation,
            motherOccupation: body.personalDetails.motherOccupation,
            studentNumber: body.personalDetails.studentPhone,
            
            // Contact Details
            houseApartmentName: body.contactDetails.house,
            placeState: body.contactDetails.place,
            postOffice: body.contactDetails.postOffice,
            country: body.contactDetails.country,
            pinCode: body.contactDetails.pincode,
            state: body.contactDetails.state,
            district: body.contactDetails.district,
            whatsappNumber: body.contactDetails.whatsappNumber,
            studentEmail: body.contactDetails.studentEmail,
            alternativeNumber: body.contactDetails.alternativeNumber,

            // Educational Details
            nameOfTheCollege: body.educationalDetails.college,
            branch: body.educationalDetails.branch,
            semester: body.educationalDetails.semester,
            hostelResident: body.educationalDetails.hostelResident === 'Yes',
            cgpa: body.educationalDetails.cgpa.toString(),

            // Bank Details
            bankName: body.bankDetails.bankName,
            accountNumber: body.bankDetails.accountNumber,
            ifscCode: body.bankDetails.ifsc,
            branchName: body.bankDetails.branchName,
            accountHolder: body.bankDetails.accountHolder,

            // Documentation Details
            photoUrl: body.files.photoUrl,
            checkUrl: body.files.checkUrl,
            aadharCardUrl: body.files.aadharCardUrl,
            collegeIdCardUrl: body.files.collegeIdCardUrl,
            incomeUrl: body.files.incomeUrl,

            // Application Meta Data
            status: 'Pending', // Default status
            applicationDate: new Date(), // Current date
        };

        // Insert the scholarship data into the database
        const result = await ScholarshipDb.insert(Scholarship_Table).values(scholarshipData).returning('*');

        // Return a successful response
        return NextResponse.json({ success: true, data: result });
    } catch (error) {
        console.error('Error inserting scholarship data:', error);
        return NextResponse.json({ success: false, message: 'Failed to insert scholarship data', error: error.message }, { status: 500 });
    }
}
