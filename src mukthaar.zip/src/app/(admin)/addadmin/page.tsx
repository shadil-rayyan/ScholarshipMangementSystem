// app/admin/page.tsx
import React from 'react';
import AddAdmin from '@/components/admin/AddAdmin';

const AdminPage: React.FC = () => {
  return (
    <div>

      <AddAdmin />
    </div>
  );
};

export default AdminPage;