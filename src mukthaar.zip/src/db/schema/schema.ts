// src\db\schema\index.ts

export * from './scholarship/scholarshipData';
